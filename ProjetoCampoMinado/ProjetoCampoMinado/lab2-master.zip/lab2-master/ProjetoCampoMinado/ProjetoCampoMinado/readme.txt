Read-me
Autor: Daniel Augusto Libanori
IDE Utilizada no Projeto: CodeBlocks
Funcionalidades: Todas Implementadas com Sucesso

Esquematico do Projeto: Em imagem .JPEG junto aos arquivos

Sistema Operacional: 	
	Windows(padrão), 
	Unix (deve-se alterar as funções limpaTela e lerChar, além de cancelar o includ do conio.h)

Arquivos:
	main.c
	funcoesAuxiliares.c (e seu respectivo header)
	interfaces.c (e seu respectivo header)
	inicializacao.c (e seu respectivo header)
	jogando.c (e seu respectivo header)


Linha de Compilação: 













		-----------    ---------    -----         -----  ----------   -------------
		|         |   /   ___   \   |    \       /    |  |   ----  \  |  -------  |
		|    ------  /   /   \   \  |     \     /     |  |   |   |  | |  |     |  |
		|   |        |   |   |   |  |      \   /      |  |   ----  /  |  |     |  |
		|   |	     |   -----   |  |   |\  ---  /|   |  |   -----    |  |     |  |
		|   |        |   -----   |  |   | \     / |   |  |   |        |  |     |  |
		|    ------  |   |   |   |  |   |  \   /  |   |  |   |        |  |     |  |
		|         |  |	 |   |   |  |   |   ---   |   |  |   |        |  -------  |
		-----------  -----   -----  -----         -----  -----        -------------

	-----         -----  -----  -----    -----    ---------    -----------     -------------
	|    \       /    |  |   |  |    \   |   |   /   ___   \   |  ------  \    |  -------  |
	|     \     /     |  |   |  |     \  |   |  /   /   \   \  |  |     \  \   |  |     |  |
	|      \   /      |  |   |  |      \ |   |  |   |   |   |  |  |      |  |  |  |     |  |
	|   |\  ---  /|   |  |   |  |   |\  \|   |  |   -----   |  |  |      |  |  |  |     |  |
	|   | \     / |   |  |   |  |   | \      |  |   -----   |  |  |      |  |  |  |     |  |
	|   |  \   /  |   |  |   |  |   |  \     |  |   |   |   |  |  |     /  /   |  |     |  |
	|   |   ---   |   |  |   |  |   |   \    |  |	|   |   |  |  ------  /    |  -------  |
	-----         -----  -----  -----    -----  -----   -----  -----------     -------------
