Arquivo leia-me, colocar explicações do programa após termina-lo. Incluir linha para compilação no terminal.
